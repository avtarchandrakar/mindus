		<meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
		<meta charset="utf-8" />
		<title>Metalite Industries</title>

		<meta name="description" content="overview &amp; stats" />
<!--		<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0" />-->

		<!-- bootstrap & fontawesome -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/bootstrap.min.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/font-awesome.min.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/loading.css" />

		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/chosen.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/Print.css" type="text/css" media="print" />
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/fakeLoader.css" />
		<!-- page specific plugin styles -->
		<link href="<?php echo base_url();?>assets/css/plugins/chosen/bootstrap-chosen.css" rel="stylesheet">
		<!-- text fonts -->
		<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Open+Sans:400,300" />

		<!-- ace styles -->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace.min.css" id="main-ace-style" />

		<!--[if lte IE 9]>
			<link rel="stylesheet" href="assets/css/ace-part2.min.css" />
		<![endif]-->
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-skins.min.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/ace-rtl.min.css" />
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/toastr.min.css" />
		

		<!--[if lte IE 9]>
		  <link rel="stylesheet" href="assets/css/ace-ie.min.css" />
		<![endif]-->

		<!-- inline styles related to this page -->

		<!-- ace settings handler -->
		<script src="<?php echo base_url();?>assets/js/ace-extra.min.js"></script>
		<link rel="stylesheet" href="<?php echo base_url();?>assets/css/jquery-ui.css" />
        <link rel="stylesheet" href="<?php echo base_url();?>assets/css/plugins/validationEngine/validationEngine.jquery.css" type="text/css"/>
		<script src="<?php echo base_url();?>assets/js/script.js"></script>


		<!-- HTML5shiv and Respond.js for IE8 to support HTML5 elements and media queries -->

		<!--[if lte IE 8]>
		<script src="assets/js/html5shiv.min.js"></script>
		<script src="assets/js/respond.min.js"></script>
		<![endif]-->
        <style type="text/css">
        .loading {
	        background:url("<?php echo base_url();?>assets/css/images/loading.gif") no-repeat 1px; 
	        height:40px; 
	        width:40px; 
	        display:none;
        }
        input[type=text]{
        	text-transform: uppercase;
        }
		.disabled {
		  opacity: 0.5
		  pointer-events: none
		  cursor: default
		}
/*        .btn_entry,.btn_modify,.btn_del{
        	display: none;
        }*/
        .no-skin .nav-list>li.active>a{
        	color:  #009900;
        }
        .blue{
        	color:  #009900;
        }
        .page-header h1{
        	color:   #009900;
        }
        .menu ,.dropdown-toggle{
        	background-color: #009900;
        	color:   #009900;
        }
        .menu-text{
        	color:   #009900;
        }
        .menu-icon,.widget-title{
        	color:   #009900;
        }
        .no-skin .nav-list>li{
        	color:   #009900;
        }
        .no-skin .nav-list>li .submenu>li>a{
        	color:   #009900;
        }
        .no-skin .nav-list>li .submenu>li>a:hover{
        	color:   #009900;
        }
        
        .ui-datepicker td>a{
        	background-color: #009900;
        }

        </style>
