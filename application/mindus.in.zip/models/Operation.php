<?
if (!defined('BASEPATH')) exit('No direct script access allowed');

class Operation extends CI_Model {


     public function approve_save($tableName,$data,$id,$full_path,$file_name)
    {
          date_default_timezone_set('Asia/Kolkata');
          $tableName1='tbl_trans3';
          $status = $this->input->post("status");
          $fields = $this->db->field_data($tableName1);
          foreach ($fields as $field)
          {
            if($field->primary_key==1)
              continue;
            $value=$this->input->post($field->name);
            if(!empty($value))
            {
                $data[$field->name]=$value;
            }
          }

          $data['cdate'] = date('Y-m-d',strtotime($this->input->post('cdate')));
          $data['company_id'] = get_cookie("ae_company_id");
          $data['filename']=$file_name;
          $data['fullpath']=$full_path;

          $cdate = date('Y-m-d',strtotime($this->input->post('cdate')));
          $company_id = get_cookie("ae_company_id");
          $filename=$file_name;
          $fullpath=$full_path;

     
          if($status=="add")
            {
            try{
            $maxsno=0;
            $query=$this->db->query("select max(cpo_sno) as maxsno from tbl_trans1");
            $result=$query->result();
            if($query->num_rows()>0)
            {
              foreach($result as $row)
              {
                $maxsno = intval($row->maxsno)+1;
              }
            }
            $data['cpo_sno']=$maxsno;
            $cpo_sno=$maxsno;

            $maxsno1='';
            if(strlen($maxsno)==1){
              $maxsno1="00".$maxsno;
            }elseif (strlen($maxsno)==2) {
              $maxsno1="0".$maxsno;
            }else{
              $maxsno1=$maxsno;
            }
            $data['cpo']='CPO/'.substr(get_cookie("ae_fnyear_name"),3,2)."-".substr(get_cookie("ae_fnyear_name"),8,2)."/".$maxsno1;
            $cpo='CPO/'.substr(get_cookie("ae_fnyear_name"),3,2)."-".substr(get_cookie("ae_fnyear_name"),8,2)."/".$maxsno1;
      // echo 'dfgfdh';die();
            $this->db->trans_begin();
            $query=$this->db->query("insert into tbl_trans3(filename,fullpath,cdate,company_id,cpo,cpo_sno) values('$filename','$fullpath','$cdate','$company_id','$cpo','$cpo_sno')");
            // $result=$query->result();
            $id=$this->db->insert_id();
            echo $query;echo $id;die();
            $this->db->insert($tableName1,$data); // insert trans1
            // $this->db->trans_commit();
            $id=$this->db->insert_id();
            echo $id; 

            }catch(Exception $e){
            $this->db->trans_rollback();
            echo "0";       
            }
        }
        if($status=="edit")
          {
          try{
              $this->db->trans_begin();  
              $id=$this->input->post('sno');
              $data['modified_by'] = get_cookie('ae_username');
              $data['modi_datetime'] = date('Y-m-d h:i:s');

              $this->db->where('id',$id);
              $this->db->update($tableName1,$data); // update trans 1
              echo $id;       
          }catch(Exception $e){
              $this->db->trans_rollback();
              echo "0";       
          }
        }


          
    }




}